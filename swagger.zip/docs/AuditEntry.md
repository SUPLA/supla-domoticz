# AuditEntry

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**event** | **int** |  | [optional] 
**created_at** | **datetime** |  | [optional] 
**ipv4** | **int** |  | [optional] 
**int_param** | **int** |  | [optional] 
**text_param** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

