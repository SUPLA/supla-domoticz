# LocationUpdateRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **bool** |  | [optional] 
**caption** | **str** |  | [optional] 
**password** | **str** | Provide new password if you want to change it. | [optional] 
**access_ids_ids** | **list[int]** | Access Identifiers identifiers to assign to this location. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

