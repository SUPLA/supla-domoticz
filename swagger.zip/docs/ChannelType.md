# ChannelType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **float** | Channel type identifier | [optional] 
**name** | **str** |  | [optional] 
**caption** | **str** |  | [optional] 
**output** | **bool** | Whether the channel is output type (i.e. can take action) or input (i.e. provide data) | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

