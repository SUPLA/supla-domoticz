# UserData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**short_unique_id** | **str** |  | [optional] 
**email** | **str** |  | [optional] 
**timezone** | **str** |  | [optional] 
**clients_registration_enabled** | **datetime** |  | [optional] 
**io_devices_registration_enabled** | **datetime** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

