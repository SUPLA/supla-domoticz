# UserUpdateRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**action** | **str** | The &#x60;change:userTimezone&#x60; requires to provide also a &#x60;timezone&#x60; value in the request. The &#x60;change:password&#x60; requires to provide also a &#x60;newPassword&#x60; and &#x60;oldPassword&#x60; in the request. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

