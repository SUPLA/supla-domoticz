# HiState

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**connected** | **bool** |  | 
**hi** | **bool** | &#x60;hi&#x60; is either &#x60;true&#x60; or &#x60;false&#x60; depending on sensor state | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

