# Body

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**function** | [**ChannelFunctionEnumNames**](ChannelFunctionEnumNames.md) |  | [optional] 
**source_icon** | **int** | ID of an existing user icon to replace with these new files. Optional. | [optional] 
**image1** | **str** |  | [optional] 
**image2** | **str** |  | [optional] 
**image3** | **str** |  | [optional] 
**image4** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

