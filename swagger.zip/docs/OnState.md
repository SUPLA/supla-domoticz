# OnState

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**connected** | **bool** |  | 
**on** | **bool** | &#x60;on&#x60; is either &#x60;true&#x60; or &#x60;false&#x60; depending on the switch state | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

