# UserIcon

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Schedule identifier | [optional] 
**images** | **list[str]** | Returned only if requested by the &#x60;include&#x60; parameter. Array contains images blobs encoded with Base64. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

