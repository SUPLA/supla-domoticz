# ChannelUpdateRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**function_id** | **int** |  | [optional] 
**param1** | **int** |  | [optional] 
**param2** | **int** |  | [optional] 
**param3** | **int** |  | [optional] 
**text_param1** | **str** |  | [optional] 
**text_param2** | **str** |  | [optional] 
**text_param3** | **str** |  | [optional] 
**caption** | **str** |  | [optional] 
**alt_icon** | **int** |  | [optional] 
**hidden** | **bool** |  | [optional] 
**location_id** | **int** |  | [optional] 
**inherited_location** | **bool** |  | [optional] 
**user_icon_id** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

