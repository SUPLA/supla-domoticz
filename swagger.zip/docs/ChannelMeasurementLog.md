# ChannelMeasurementLog

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**date_timestamp** | **int** |  | [optional] 
**temperature** | **float** | Temperature in Celsius | [optional] 
**humidity** | **float** | Humidity percent. Available only if channel function is &#x60;HUMIDITYANDTEMPERATURE&#x60;. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

