# ScheduleClosestExecutions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**past** | [**list[SchedulePast]**](SchedulePast.md) |  | [optional] 
**future** | [**list[ScheduleFuture]**](ScheduleFuture.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

