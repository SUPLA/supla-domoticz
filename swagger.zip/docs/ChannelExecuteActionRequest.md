# ChannelExecuteActionRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**action** | [**ChannelFunctionActionEnum**](ChannelFunctionActionEnum.md) |  | 
**percentage** | **int** |  | [optional] 
**color** | **str** |  | [optional] 
**color_brightness** | **int** |  | [optional] 
**brightness** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

